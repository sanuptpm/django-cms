# -*- coding: utf-8 -*-

__version__ = '3.4.1'

default_app_config = 'cms.apps.CMSConfig'
